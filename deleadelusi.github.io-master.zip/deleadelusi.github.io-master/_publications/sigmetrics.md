---
title: "Efficient Federated Learning with Self-Regulating Clients"
collection: publications
permalink: /publication/sigmetrics
excerpt: 'Proposed a self regulating clients to save both local computation and communication'
date: 2022-06-09
venue: 'ACM SIGMETRICS / IFIP PERFORMANCE 2022'
paperurl: 'https://www.researchgate.net/profile/Zahidur-Talukder-2/publication/361939981_FedSRC_Efficient_Federated_Learning_with_Self-Regulating_Clients/links/62cda209c276426014a9677c/FedSRC-Efficient-Federated-Learning-with-Self-Regulating-Clients.pdf'
citation: 'Talukder, Zahidur, and Mohammad A. Islam. "Efficient Federated Learning with Self-Regulating Clients."'
---
