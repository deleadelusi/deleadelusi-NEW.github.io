---
title: "Towards Server-Level Power Monitoring in Data Centers Using Single-Point Voltage Measurement"
collection: publications
permalink: /publication/sensys
excerpt: 'Proposed an easy approach to server level monitoring using voltage signal'
date: 2022-06-09
venue: 'ACM SenSys 2022'

citation: 'Gupta, Pranjol Sen, Talukder, Zahidur, and Mohammad A. Islam. "Efficient Federated Learning with Self-Regulating Clients."'
---
